 
client_script "@Badger-Anticheat/acloader.lua"